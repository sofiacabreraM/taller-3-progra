import './Top_container/TopContainer'
import './Bottom_container/Bottomcontainer'
import './button_comment/button_comment'
import { loadCss } from '../../utilidades/styles';
import styles from './post.css'
export default class Post extends HTMLElement {
    constructor(){
        super();
        this.attachShadow({mode: "open"})
    }

    connectedCallback(){
        this.render();
    }

    render(){
        if(this.shadowRoot) this.shadowRoot.innerHTML = ``
        loadCss(this, styles)
        const card = this.ownerDocument.createElement("div");
        card.classList.add("card");
        
        const topContainer = this.ownerDocument.createElement("app-topcontainer");
        card.appendChild(topContainer);
        
        const img = this.ownerDocument.createElement("img");
        img.classList.add("img_Post");
        img.src = "https://i.pinimg.com/564x/96/69/67/966967b8a715f50a892c238e464a4fd6.jpg";
        card.appendChild(img);

        const Bottomcontainer  = this.ownerDocument.createElement("app-bottomcontainer");
        card.appendChild(Bottomcontainer); 

        const CommentButton = this.ownerDocument.createElement("comment-button");
        card.appendChild(CommentButton);
        this.shadowRoot?.appendChild(card);
   
    }
}

customElements.define('app-post', Post);