import styles from '../post.css'
import { loadCss } from '../../../utilidades/styles';
export default class Bottomcontainer extends HTMLElement {
    constructor(){
        super();
        this.attachShadow({mode: "open"})
    }

    connectedCallback(){
        this.render();
    }

    render(){
        if (this.shadowRoot) this.shadowRoot.innerHTML = "";
        loadCss(this, styles)

        const container = this.ownerDocument.createElement("div");
        container.classList.add("container_comment");

        const h2 = this.ownerDocument.createElement("h2");
        h2.classList.add("name_comment");
        h2.textContent = "Maria_camila";
        container.appendChild(h2);
        const h3 = this.ownerDocument.createElement("h3");
        h3.classList.add("comment");
        h3.textContent = "beautiful sun";
        container.appendChild(h3);
        this.shadowRoot?.appendChild(container);

        
        
    }
}

customElements.define('app-bottomcontainer', Bottomcontainer);