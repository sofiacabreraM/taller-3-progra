import styles from '../datoslogin.css'
import { loadCss } from '../../../utilidades/styles';


export default class formatologin extends HTMLElement {
    constructor(){
        super();
        this.attachShadow({mode: "open"})
    }

    connectedCallback(){
        this.render();
    }

    render(){
        if (this.shadowRoot) this.shadowRoot.innerHTML = "";
        loadCss(this, styles)

        const loginForm = this.ownerDocument.createElement("div");
        loginForm.classList.add("login-form");

        const Bienvenidos = this.ownerDocument.createElement("h1");
        Bienvenidos.classList.add("Bienvenido_login");
        Bienvenidos.textContent = "Bienvenido";
        loginForm.appendChild(Bienvenidos);
    
        const emailInput = this.ownerDocument.createElement("input");
        emailInput.setAttribute("type", "email");
        emailInput.setAttribute("name", "email");
        emailInput.setAttribute("placeholder", "Email");
        loginForm.appendChild(emailInput);
    
        const passwordInput = this.ownerDocument.createElement("input");
        passwordInput.setAttribute("type", "password");
        passwordInput.setAttribute("name", "password");
        passwordInput.setAttribute("placeholder", "Password");
        loginForm.appendChild(passwordInput);
    
        const submitButton = this.ownerDocument.createElement("button");
        submitButton.setAttribute("type", "submit");
        submitButton.textContent = "Login";
        loginForm.appendChild(submitButton);
    
        this.shadowRoot?.appendChild(loginForm);

        
        
    }
}

customElements.define('app-formatologin', formatologin);