import styles from './datoslogin.css'
import { loadCss } from '../../utilidades/styles';

import './formatologin/formatologin'



export default class Datoslogin extends HTMLElement {
    constructor(){
        super();
        this.attachShadow({mode: "open"})
    }

    connectedCallback(){
        this.render();
    }

    render(){
        if (this.shadowRoot) this.shadowRoot.innerHTML = "";
        loadCss(this, styles)



        const Card= this.ownerDocument.createElement("div");
        Card.classList.add("Cardlogin");

        const img = this.ownerDocument.createElement("img");
        img.classList.add("img_login");
        img.src = "https://static.vecteezy.com/system/resources/previews/005/879/539/original/cloud-computing-modern-flat-concept-for-web-banner-design-man-enters-password-and-login-to-access-cloud-storage-for-uploading-and-processing-files-illustration-with-isolated-people-scene-free-vector.jpg";
        Card.appendChild(img);

        const formatologin = this.ownerDocument.createElement("app-formatologin");
        Card.appendChild(formatologin); 

        this.shadowRoot?.appendChild(Card);
    }
}

customElements.define('app-datoslogin', Datoslogin);