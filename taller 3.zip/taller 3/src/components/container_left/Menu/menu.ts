import styles from '../container.css'
import { loadCss } from '../../../utilidades/styles';



export default class Menu extends HTMLElement {
    constructor(){
        super();
        this.attachShadow({mode: "open"})
    }

    connectedCallback(){
        this.render();
    }

    render(){
        if (this.shadowRoot) this.shadowRoot.innerHTML = "";
        loadCss(this, styles)

        const container= this.ownerDocument.createElement("div");
        container.classList.add("container_Menu");

        const Home= this.ownerDocument.createElement("h3");
        Home.classList.add("Menu_seccion");
        Home.textContent = "Home";
        container.appendChild(Home);

        const Notifications= this.ownerDocument.createElement("h3");
        Notifications.classList.add("Menu_seccion");
        Notifications.textContent = "Notifictions";
        container.appendChild(Notifications);

        const Explore= this.ownerDocument.createElement("h3");
        Explore.classList.add("Menu_seccion");
        Explore.textContent = "Explore";
        container.appendChild(Explore);

        const Message= this.ownerDocument.createElement("h3");
        Message.classList.add("Menu_seccion");
        Message.textContent = "Messages";
        container.appendChild(Message);

        const profile= this.ownerDocument.createElement("h3");
        profile.classList.add("Menu_seccion");
        profile.textContent = "profile";
        container.appendChild(profile);

       
        this.shadowRoot?.appendChild(container);
        
        
    }
}

customElements.define('app-menu', Menu);