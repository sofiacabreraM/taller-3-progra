import { loadCss } from '../../utilidades/styles';
import styles from './container.css'
import './Numbers/numbers'
import './Menu/menu'

export default class Menugeneral extends HTMLElement {
    constructor(){
        super();
        this.attachShadow({mode: "open"})
    }

    connectedCallback(){
        this.render();
    }

    render(){
        if(this.shadowRoot) this.shadowRoot.innerHTML = ``
        loadCss(this, styles)
        const container= this.ownerDocument.createElement("div");
        container.classList.add("container_general");


        const img = this.ownerDocument.createElement("img");
        img.classList.add("img_Profile");
        img.src = "https://i.pinimg.com/564x/a8/1a/51/a81a51ca04c3eef06cb73a53831a8d22.jpg";
        container.appendChild(img);

        const h1 = this.ownerDocument.createElement("h3");
        h1.classList.add("Post");
        h1.textContent = "@Laitana";
        container.appendChild(h1);
        const Menu = this.ownerDocument.createElement("app-menu");
        container.appendChild(Menu)
        const numbers  = this.ownerDocument.createElement("app-numbers");
        container.appendChild(numbers); 
        
        
        

        

        this.shadowRoot?.appendChild(container);
   
    }
}

customElements.define('app-menugeneral', Menugeneral);