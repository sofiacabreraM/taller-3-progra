import styles from '../container.css'
import { loadCss } from '../../../utilidades/styles';


export default class Numbers extends HTMLElement {
    constructor(){
        super();
        this.attachShadow({mode: "open"})
    }

    connectedCallback(){
        this.render();
    }

    render(){
        if (this.shadowRoot) this.shadowRoot.innerHTML = "";
        loadCss(this, styles)

        const container= this.ownerDocument.createElement("div");
        container.classList.add("container_numbers");

        const Number1= this.ownerDocument.createElement("h3");
        Number1.classList.add("Number");
        Number1.textContent = "20";
        container.appendChild(Number1);

        const Number2= this.ownerDocument.createElement("h3");
        Number2.classList.add("posts");
        Number2.textContent = "posts";
        container.appendChild(Number2);

        const linea = this.ownerDocument.createElement("div");
        linea.classList.add("linea");

        const linea1= this.ownerDocument.createElement("h3");
        linea.textContent = ".";
        container.appendChild(linea1);
       
        container.appendChild(linea);


        const Number4= this.ownerDocument.createElement("h3");
        Number4.classList.add("Number");
        Number4.textContent = "1983";
        container.appendChild(Number4);

        const Number5= this.ownerDocument.createElement("h3");
        Number5.classList.add("follows");
        Number5.textContent = "follows";
        container.appendChild(Number5);


        const linea2= this.ownerDocument.createElement("div");
        linea2.classList.add("linea");

        const linea3= this.ownerDocument.createElement("h3");
        linea3.textContent = ".";
        container.appendChild(linea1);
       
        container.appendChild(linea2);

        const Number6= this.ownerDocument.createElement("h3");
        Number6.classList.add("Number");
        Number6.textContent = "678";
        container.appendChild(Number6);

        const Number3= this.ownerDocument.createElement("h3");
        Number3.classList.add("followers");
        Number3.textContent = "followers";
        container.appendChild(Number3);

       
        this.shadowRoot?.appendChild(container);
        
        
    }
}

customElements.define('app-numbers', Numbers);