import { loadCss } from '../../utilidades/styles';
import styles from './Dasbhoard.css'
export default class Dashboard extends HTMLElement{
    constructor(){
        super();
        this.attachShadow({mode: 'open'});
    }

    connectedCallback(){
        this.render()
    }
    render(){  
        if(this.shadowRoot) this.shadowRoot.innerHTML = ``;
        loadCss(this, styles)

   
        const containerWrapper = this.ownerDocument.createElement("div");
        containerWrapper.classList.add("container-wrapper");
        
        const containerLeft = this.ownerDocument.createElement("div");
        containerLeft.classList.add("container");
        
        const Menugeneral = this.ownerDocument.createElement("app-menugeneral");
        containerLeft.appendChild(Menugeneral);
        containerWrapper.appendChild(containerLeft);
        
        const containeRight = this.ownerDocument.createElement("div");
        containeRight.classList.add("container_dasbhoarRigth");
        
        const nav = this.ownerDocument.createElement("app-nav");
        const Destacadas = this.ownerDocument.createElement('app-destacadas');
        const Post = this.ownerDocument.createElement("app-post");
        containeRight.appendChild(nav);
        containeRight.appendChild(Destacadas);
        containeRight.appendChild(Post);
        containerWrapper.appendChild(containeRight);
        
        this.shadowRoot?.appendChild(containerWrapper);


       
        }
    
}

customElements.define('app-dashboard', Dashboard);