import { loadCss } from '../../utilidades/styles';
//import styles from './Dasbhoard.css'
import './../../components/export'

export default class login extends HTMLElement{
    constructor(){
        super();
        this.attachShadow({mode: 'open'});
    }

    connectedCallback(){
        this.render()
    }
    render(){  
        if(this.shadowRoot) this.shadowRoot.innerHTML = ``;
        //loadCss(this, styles)

   
    
        
        const Datoslogin = this.ownerDocument.createElement("app-datoslogin");
        this.shadowRoot?.appendChild(Datoslogin);
        


       
        }
    
}

customElements.define('app-login', login);